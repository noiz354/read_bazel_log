

use scanner_rust::ScannerAscii;

use scanner_rust::generic_array::typenum::U64;
use scanner_rust::Scanner as scanner2;
use scanner_rust::ScannerError;

fn main() {

    let mut real_path = String::from("");
    real_path.push_str("path.log");

    let mut scan: scanner2<_, U64> = scanner2::scan_path2(real_path).unwrap();

    let command_log_path = scan.next_line().unwrap().unwrap();

    use std::process::Command;

    let mut copy_file = Command::new("cp");

    copy_file.arg(command_log_path)
            .arg(".");

    let _ = copy_file.output().expect("failed to execute process");

}
